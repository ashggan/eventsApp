<?php 
class Cms5ce5fbc0496ca335276036_4d63c79e70b18b8c6b3b508bd15c9336Class extends Cms\Classes\PartialCode
{

}
