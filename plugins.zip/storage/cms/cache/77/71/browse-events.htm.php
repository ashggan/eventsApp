<?php 
class Cms5ce672e2a9150897829495_3bea2f58e63a5d63b94e8171694a8145Class extends Cms\Classes\PageCode
{

}
