<?php 
class Cms5ce5fbc0326d5777553193_801024710e6c17570f280626ada1e245Class extends Cms\Classes\LayoutCode
{

}
