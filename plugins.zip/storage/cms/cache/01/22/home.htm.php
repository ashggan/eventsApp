<?php 
class Cms5ce5fbc0347a7270205635_ab2cff5427c8fa26fa5667faca78656dClass extends Cms\Classes\PageCode
{

}
