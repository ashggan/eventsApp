var dz = uploadDropZones['{{ id }}'];
if(dz) { dz.uploader.dropzone.removeAllFiles(); dz.uploader.evalIsPopulated(); }